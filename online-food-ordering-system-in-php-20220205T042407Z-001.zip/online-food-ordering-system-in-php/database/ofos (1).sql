-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2021 at 01:57 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ofos`
--

-- --------------------------------------------------------

--
-- Table structure for table `a`
--

CREATE TABLE `a` (
  `id` int(11) NOT NULL,
  `un` varchar(50) DEFAULT NULL,
  `ps` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `a`
--

INSERT INTO `a` (`id`, `un`, `ps`) VALUES
(1, 'a', 'b'),
(2, 'c', 'd');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `un` varchar(50) DEFAULT NULL,
  `ps` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`un`, `ps`) VALUES
('admin', 'a123');

-- --------------------------------------------------------

--
-- Table structure for table `order_booking`
--

CREATE TABLE `order_booking` (
  `id` int(11) NOT NULL,
  `pname` varchar(50) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `cname` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mno` varchar(20) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `user_id` int(10) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_booking`
--

INSERT INTO `order_booking` (`id`, `pname`, `price`, `cname`, `email`, `mno`, `address`, `city`, `type`, `user_id`, `status`) VALUES
(69, 'Bargar', '80.00', 'Rahul', 'debnathrahul052@gmail.com', '7908861937', 'Barasat banamalipur,', 'barasat', 'ofline', 7, 'Delivered'),
(70, 'Bargar', '80.00', 'Rahul', 'debnathrahul052@gmail.com', '7908861937', 'Barasat banamalipur,', 'barasat', 'ofline', 7, 'Delivered'),
(71, 'pizza', '100', 'rohit', 'r@gmail.com', '7908861937', 'Barasat ', 'barasat', 'ofline', 8, 'Delivered'),
(72, 'pizza', '100', 'Rahul Debnath', 'debnathrahul052@gmail.com', '7908861937', 'Habra', 'Habra', 'ofline', 10, 'ordered');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `img`) VALUES
(1, 'pizza', '100', 'image/WhatsApp Image 2021-05-23 at 11.39.04 AM (1).jpeg'),
(2, 'Mushroom Masala', '150.00', 'image/WhatsApp Image 2021-05-23 at 11.39.04 AM.jpeg'),
(17, 'Coffe', '80.00', 'image/WhatsApp Image 2021-05-23 at 11.39.03 AM (1).jpeg'),
(18, 'Chicken Cheese Balls', '75.00', 'image/WhatsApp Image 2021-05-23 at 11.39.03 AM.jpeg'),
(19, 'Bamboo Chicken', '200.00', 'image/WhatsApp Image 2021-05-23 at 11.39.02 AM (1).jpeg'),
(20, 'Veg Korma', '120.00', 'image/WhatsApp Image 2021-05-23 at 11.39.02 AM.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(15) NOT NULL,
  `name` varchar(20) CHARACTER SET latin1 NOT NULL,
  `email` varchar(30) CHARACTER SET latin1 NOT NULL,
  `phone` varchar(50) CHARACTER SET latin1 NOT NULL,
  `password` varchar(50) CHARACTER SET latin1 NOT NULL,
  `address` varchar(20) CHARACTER SET latin1 NOT NULL,
  `city` varchar(10) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `name`, `email`, `phone`, `password`, `address`, `city`) VALUES
(9, 'abc', 'abc@gmail.com', '1234567892', '2e407ef923383086d88e003626cfde63', 'hbara', 'habra'),
(10, 'Rahul Debnath', 'debnathrahul052@gmail.com', '7908861937', '2e407ef923383086d88e003626cfde63', 'Habra', 'Habra');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `a`
--
ALTER TABLE `a`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_booking`
--
ALTER TABLE `order_booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `a`
--
ALTER TABLE `a`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_booking`
--
ALTER TABLE `order_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
