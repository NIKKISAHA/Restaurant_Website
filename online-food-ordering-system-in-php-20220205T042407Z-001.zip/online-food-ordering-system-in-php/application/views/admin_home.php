<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link type="text/css" rel="stylesheet" href="<?=base_url('tool/css/style.css'); ?>">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: black;
}

* {
  box-sizing: border-box;
}


.container {
  padding: 16px;
  background-color: silver;
}


input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #fff;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}


hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}


.loginbtn {
  background-color: #337ab7;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}


a {
  color: dodgerblue;
}


.signup {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body>

<form action="<?php echo base_url();?>index.php/admin/login" method="post">
 <div class="back2">
 <center><img src="<?php echo base_url();?>tool\img\logo.png" alt="" height="100" width="200"></center>
  <div class="container" style="background:;color:#e68a00;">
   <center><h1>Login</h1></center>
    <label for="id"><b>User_id</b></label>
    <input type="text" placeholder="Enter User_id" name="un" required>
    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="ps" required>

    <button type="submit" class="loginbtn" name="submit">Login</button>
  </div>
  
  
    
    
  </div>
 </div>
</form>

</body>
</html>
