<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE-edge" />
<meta name="viewport" content="width=device-width" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Admin Home</title>
<link type="text/css" rel="stylesheet" href="<?=base_url('tool/css/s2.css'); ?>">
<link type="text/css" rel="stylesheet" href="<?= base_url('tool/css/bootstrap.min.css') ?>" >
<script src="<?= base_url('tool/js/bootstrap.js') ?>"> </script>
<script src="<?= base_url('tool/js/jquery-3.2.1.min.js')?>"></script>
<script src="<?= base_url('tool/js/myjs.js') ?>"></script>
<script>
</script>
</head>
<body>
<body style="background:silver;color:;">
<div class="container-fluid" style="background:#333333;color:#e68a00;">
<div class="col-sm-3">
<img src="<?php echo base_url();?>tool\img\logo.png" alt="" height="100" width="200"></div>
<div class="col-sm-9"><br>
<button id="btn" >--</button>
<div id='nav'>
<?php 
echo $un=$this->session->userdata('un');
?>
<?php 
include('amanu.php');
?>
</div>
</div>
</div>

<div class="container-fluid" id="banner">
<div id="form" class="col-sm-7">
<h3>Resept</h3>
<table class="table">
<tr>
<td>Order ID</td>
<td><?= $res->id; ?></td>
<td>Name</td>
<td><?= $res->cname; ?></td>
</tr>
<tr>
<td>Product</td>
<td><?= $res->pname; ?></td>
<td>Price</td>
<td><?= $res->price; ?></td>
</tr>
<tr>
<td>E-Mail</td>
<td><?= $res->email; ?></td>
<td>Mobile No.</td>
<td><?= $res->mno; ?></td>
</tr>
<tr>
<td>Address</td>
<td><?= $res->address; ?></td>
<td>City</td>
<td><?= $res->city; ?></td>
</tr>
<tr>
<td><button class="btn btn-primary" onclick="window.print()">Print Now</button></td>
</tr>
</table>
</div>
</div>
<div class="container-fluid" style="background:blue;color:white;">

</div>
</body>
</html>