<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE-edge" />
<meta name="viewport" content="width=device-width" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Home</title>
<link type="text/css" rel="stylesheet" href="<?=base_url('tool/css/s2.css'); ?>">
<link type="text/css" rel="stylesheet" href="<?= base_url('tool/css/bootstrap.min.css') ?>" >
<script src="<?= base_url('tool/js/bootstrap.js') ?>"> </script>
<script src="<?= base_url('tool/js/jquery-3.2.1.min.js')?>"></script>
<script src="<?= base_url('tool/js/myjs.js') ?>"></script>
<script>

</script>
</head>
<body style="background:silver;color:;">
<div class="container-fluid" style="background:#333333;color:#e68a00;">
<div class="col-sm-3">
<img src="<?php echo base_url();?>tool\img\logo.png" alt="" height="100" width="200"></div>
<div class="col-sm-9"><br>
<button id="btn" >--</button>
<div id='nav'>
<?php 
include('manu.php');
?>
</div>
</div>
</div>

<div class="container-fluid" id="banner">
<div id="form" class="col-sm-7"><br>
<?php echo validation_errors(); ?>

<?php echo form_open('Welcome/form_validation'); ?>


<table class="table">
<h1>User Registration</h1>
<tr>
<td>Enter Name</td>
<td><?= form_input(['name'=>'name','class'=>'form-control','value'=>set_value('name')]);?></td>

</tr>
<tr>
<td>Enter E-Mail</td>
<td><?= form_input(['name'=>'email','class'=>'form-control','value'=>set_value('email')]);?></td>
</tr>
<tr>
<td>Enter Mobile No</td>
<td><?= form_input(['name'=>'mno','class'=>'form-control','value'=>set_value('mno')]);?></td>
</tr>
<tr>
<td>Password</td>
<td><?= form_password(['name'=>'pass','class'=>'form-control','value'=>set_value('pass')]);?></td>
</tr>
<tr>
<td>Enter Address</td>
<td><?= form_input(['name'=>'address','class'=>'form-control','value'=>set_value('address')]);?></td>
</tr>
<tr>
<td>Enter City</td>
<td><?= form_input(['name'=>'city','class'=>'form-control','value'=>set_value('city')]);?></td>
</tr>
<tr>
<td><input type="submit" name="submit" value="submit" class="btn btn-primary"></td>
<td>Have an account?<b><?php echo anchor('Welcome/login','Login'); ?></b></td>
</tr>
</table>
</div>
</div>
<div class="container-fluid" style="background:blue;color:white;">

</div>
</body>
</html>