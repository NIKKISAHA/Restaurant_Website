<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE-edge" />
<meta name="viewport" content="width=device-width" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Admin Home</title>
<link type="text/css" rel="stylesheet" href="<?=base_url('tool/css/s2.css'); ?>">
<link type="text/css" rel="stylesheet" href="<?= base_url('tool/css/bootstrap.min.css') ?>" >
<script src="<?= base_url('tool/js/bootstrap.js') ?>"> </script>
<script src="<?= base_url('tool/js/jquery-3.2.1.min.js')?>"></script>
<script src="<?= base_url('tool/js/myjs.js') ?>"></script>
<script>

</script>
</head>
<body style="background:silver;color:;">
<div class="container-fluid" style="background:#333333;color:#e68a00;">
<div class="col-sm-3">
<img src="<?php echo base_url();?>tool\img\logo.png" alt="" height="100" width="200"></div>
<div class="col-sm-9"><br>
<button id="btn" >--</button>
<div id='nav'>
<?php 
echo $un=$this->session->userdata('un');
?>
<?php 
include('amanu.php');
?>
</div>
</div>
</div>

<div class="container-fluid" id="banner">
<div id="form" class="col-sm-7">
<form action="<?php echo base_url();?>index.php/admin_welcome/product_update2" method="post" enctype="multipart/form-data">
<h1>Product Insert</h1>

<table class="table">
<input type="hidden" name="id" value="<?=$data->id?>">
<tr>
<td>Enter Name</td>
<td>
	<input type="text" name="name" placeholder="Enter Name" class="form-control" value="<?=$data->name ?>" >

</td>
<td><?=  form_error('name'); ?></td>
</tr>
<tr>
<td>Enter Price</td>
<td>
	<input type="text" name="price" placeholder="Enter Price" class="form-control" value="<?=$data->price ?>" >

</td>
<td><?= form_error('price') ?></td>
</tr>
<tr>
<td>Enter Type</td>
<td>
	<input type="text" name="type" placeholder="Enter Type" class="form-control" value="<?=$data->type ?>" >

</td>
<td><?= form_error('type') ?></td>
</tr>
<tr>
<td>Enter Image</td>
<td><input type="file" name="upload" class="form-control" value="<?=$data->img ?>">
</td>
</tr>
<td>
  
  <input type="submit" name="sub" value="Save" class="btn btn-primary">
	</td>
<td><br>
<?php 
// if($fb=$this->session->flashdata('fb'));
// {
// 	echo $fb;
// }
?>
</td>
</tr>
</table>
</div>
</div>


</div>
</body>
</html>