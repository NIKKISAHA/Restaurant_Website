<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE-edge" />
<meta name="viewport" content="width=device-width" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Edit</title>
<link type="text/css" rel="stylesheet" href="<?=base_url('tool/css/s2.css'); ?>">
<link type="text/css" rel="stylesheet" href="<?= base_url('tool/css/bootstrap.min.css') ?>" >
<script src="<?= base_url('tool/js/bootstrap.js') ?>"> </script>
<script src="<?= base_url('tool/js/jquery-3.2.1.min.js')?>"></script>
<script src="<?= base_url('tool/js/myjs.js') ?>"></script>
<script>

</script>
</head>
<body style="background:silver;color:;">
<div class="container-fluid" style="background:#333333;color:#e68a00;">
<div class="col-sm-3">
<img src="<?php echo base_url();?>tool\img\logo.png" alt="" height="100" width="200"></div>
<div class="col-sm-9"><br>
<button id="btn" >--</button>
<div id='nav'>
<?php 
echo $un=$this->session->userdata('un');
?>
<?php 
include('amanu.php');
?>
</div>
</div>
</div>

<div class="container-fluid" id="banner">
<div id="form" class="col-sm-7">
<h1>Edit Account</h1>
<?= form_open('Welcome/edit2') ?>
<form action="<?php echo base_url();?>index.php/Welcome/edit2" method="post">

<input type="hidden" name="user_id" value="<?= $data->user_id; ?>" />
<table class="table">
<tr>
<td>Enter Name</td>
<td>
    <input type="text" name="name"  placeholder="Enter Name"  class="form-control" value="<?= $data->name ?>">
</td>
<td><?=  form_error('name'); ?></td>
</tr>
<tr>
<td>Enter Email</td>
<td>
     <input type="text" name="email"  placeholder="Enter Email"  class="form-control" value="<?= $data->email ?>">

</td>
<td><?= form_error('email') ?></td>
</tr>
<tr>
<td>Phone no</td>
<td>
     <input type="text" name="phone"  placeholder="Enter Phonr_no"  class="form-control" value="<?= $data->phone ?>">
</td>
<td><?=  form_error('phone'); ?></td>
</tr>
<tr>
<td>Enter city</td>
<td>
     <input type="text" name="city"  placeholder="Enter City"  class="form-control" value="<?= $data->city ?>">

	</td>
<td><?=  form_error('city'); ?></td>
</tr>
<tr>
<td>Enter Address</td>
<td>
     <input type="text" name="address"  placeholder="Enter address"  class="form-control" value="<?= $data->address ?>">
    


</td>
<td><?= form_error('address') ?></td>
</tr>
<td><input type="submit" name="sub" value="save"  class="btn btn-primary"></td>
<td><br>
<?php 
/*if($fb=$this->session->flashdata('fb'));
{
	echo $fb;
}*/
?>
</td>
</tr>
</table>
</div>
</div>
</form>
</div>
</body>
</html>