<!DOCTYPE html>
<html>
<head>
	<title>abc</title>
</head>
<body>
<form method="post" action="<?php echo base_url().'index.php/Mailsent/sent';?>">
	sender email: <input type="text" name="email"><br>
	subject: <input type="text" name="subject"><br>
	body: <input type="text" name="body"><br>
	<input type="submit" name="submit" value="submit">
</form>
</body>
</html>