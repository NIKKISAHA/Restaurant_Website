<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE-edge" />
<meta name="viewport" content="width=device-width" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>my order</title>
<link type="text/css" rel="stylesheet" href="<?=base_url('tool/css/s2.css'); ?>">
<link type="text/css" rel="stylesheet" href="<?= base_url('tool/css/bootstrap.min.css') ?>" >
<script src="<?= base_url('tool/js/bootstrap.js') ?>"> </script>
<script src="<?= base_url('tool/js/jquery-3.2.1.min.js')?>"></script>
<script src="<?= base_url('tool/js/myjs.js') ?>"></script>
<script>

</script>
<style>

</style>
</head>
<body style="background:silver;color:;">
<div class="container-fluid" style="background:#333333;color:#e68a00;">
<div class="col-sm-3">
<img src="<?php echo base_url();?>tool\img\logo.png" alt="" height="100" width="200"></div>
<div class="col-sm-9"><br>
<button id="btn" >--</button>
<div id='nav'>
<?php 
 $un=$this->session->userdata('us');
?>
<?php 
include('manu.php');
?>
</div>
</div>
</div>

<div class="container-fluid" id="banner">
<div id="form" class="col-sm-9">
<h3 style="color:blue">My order</h3>
<table class="table">
<tr>
<td style="color:red">Order ID</td>
<td style="color:red">Name</td>
<td style="color:red">Address</td>
<td style="color:red">City</td>
<td style="color:red">Product</td>
<td style="color:red">Price</td>
<td style="color:red">E-mail</td>
<td style="color:red">Mobile No</td>
<td style="color:red">Status</td>
<td style="color:red">Action</td>

</tr>
</tr>
<?php 
foreach($ofres as $of){
?>
<tr>
<td><?= $of->id; ?></td>
<td><?= $of->cname; ?></td>
<td><?= $of->address; ?></td>
<td><?= $of->city; ?></td>
<td><?= $of->pname; ?></td>
<td><?= $of->price; ?></td>
<td><?= $of->email; ?></td>
<td><?= $of->mno; ?></td>
<td><?= $of->status; ?></td>
<td><a href="deletedata?del=<?php echo $of->id ?>">delete</a></td>

</tr>
<?php 
}
?>
</table>
</div>
</div>
<div class="container-fluid" style="background:#333333;color:#e68a00;">
<h2 align="center"><h3>Contact: <span>1234567890</span></h3>
              Copyright &copy; <a href="#">2021</a> All Rights Reserved<br>
            Design by Sandeep Agarwal,Soumi Koley,Sipra Bera</a></section></h2>
</div>
<h3 style="background:;color:#e68a00;">Follow Us </h3>
            <ul id="icons">
              <li><a href="#" class="normaltip"><img src="<?php echo base_url();?>tool\img\icon1.jpg" alt="" height="50" width="50"></a></li>
              <li><a href="#" class="normaltip"><img src="<?php echo base_url();?>tool\img\icon2.jpg" alt=""height="50" width="50"></a></li>
              <li><a href="#" class="normaltip"><img src="<?php echo base_url();?>tool\img\icon3.jpg" alt=""height="50" width="50"></a></li>
              <li><a href="#" class="normaltip"><img src="<?php echo base_url();?>tool\img\icon4.jpg" alt=""height="50" width="50"></a></li>
              
            </ul>
</body>
</html>