<script>
	$('document').ready(function() {
		$('#pro').click(function() {
			$('#adminproduct').slideToggle();
			$('#adminorder').hide();
			$('#adminpay').hide();
		});

		$('#order').click(function() {
			$('#adminorder').slideToggle();
			$('#adminproduct').hide();
			$('#adminpay').hide();
		});

		$('#pay').click(function() {
			$('#adminpay').slideToggle();
			$('#adminorder').hide();
			$('#adminproduct').hide();
		});
	});
</script>
<?php


if (!$this->session->userdata('us')) {  ?>
	<ul>
		<li><b><?php echo anchor('Welcome/home', 'Home'); ?></b></li>
		<li><b><?php echo anchor('Welcome/product', 'Product'); ?></b></li>
		<li><b><?php echo anchor('Welcome/contect', 'Contact Us'); ?></b></li>
		<li><b><?php echo anchor('Welcome/user_registration', 'Registration/Login'); ?></b></a></li>
	</ul>
<?php } ?>

<?php if ($un = $this->session->userdata('us')) {  ?>
	<ul>
		<li><b><?php echo anchor('Welcome/home', 'Home'); ?></b></li>
		<li><b><?php echo anchor('Welcome/product', 'Product'); ?></b></li>
		<li><b><?php echo anchor('Welcome/contect', 'Contact Us'); ?></b></li>
		<li><b><?php echo anchor('Welcome/changepassword', 'Change Password'); ?></b></li>
		<li><b><?php echo anchor('Welcome/logout', 'logout'); ?></b></a></li>


		<li><a href="#" id='pro'><b><?php print_r($un->name)  ?></b></a><br>
			<div class="col-sm-12" id="adminproduct" style="background:#333333;color:white;z-index:50;">
				<p>
					<center><?= anchor('Welcome/profile', 'Profile'); ?></center>
				</p>
				<p>
					<center><?= anchor('Welcome/my_order', 'My order'); ?></center>
				</p>

		</li>
	</ul>
<?php } ?>