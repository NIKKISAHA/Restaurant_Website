<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE-edge" />
<meta name="viewport" content="width=device-width" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Home</title>
<link type="text/css" rel="stylesheet" href="<?=base_url('tool/css/s2.css'); ?>">
<link type="text/css" rel="stylesheet" href="<?= base_url('tool/css/bootstrap.min.css') ?>" >
<script src="<?= base_url('tool/js/bootstrap.js') ?>"> </script>
<script src="<?= base_url('tool/js/jquery-3.2.1.min.js')?>"></script>
<script src="<?= base_url('tool/js/myjs.js') ?>"></script>
<script>

</script>
</head>
<body style="background:#0e0d0d;color:;">
<div class="container-fluid" style="background:#333333;color:#e68a00;">
<div class="col-sm-3">
<img src="<?php echo base_url();?>tool\img\logo.png" alt="" height="100" width="200"></div>
<div class="col-sm-9"><br>
<button id="btn" >--</button>
<div id='nav'>
	<?php 
$un=$this->session->userdata('us');
 // print_r($un->name);
?>
<?php 
include('manu.php');
?>
</div>
</div>
</div>

<div id="form" class="col-sm-7"><br>
	<center><h1 style="background:;color:#ac6c0c;">My Profile</h1></center>
<table class="table">
	<center><img src="<?php echo base_url();?>tool\img\profile_logo.jpg" alt="" height="200" width="200"></center>
<tr>
<td style="background:;color:#ac6c0c;"><center><b>Name</b></center></td>

<td><center><?= $un->name; ?></center></td>
</tr>
<tr>
<td style="background:;color:#ac6c0c;"><center><b>User_Id</b></center></td>
<td><center><?= $un->user_id; ?></center></td>
</tr>
<tr>
<td style="background:;color:#ac6c0c;"><center><b>Email</b></center></td>
<td><center><?= $un->email; ?></center></td>
</tr>
<tr>
<td style="background:;color:#ac6c0c;"><center><b>Phone_no</b></center></td>
<td><center><?= $un->phone; ?></center></td>
</tr>
<tr>
<td style="background:;color:#ac6c0c;"><center><b>Address</b></center></td>
<td><center><?= $un->address; ?></center></td>
</tr>
<tr>

<td style="background:;color:#ac6c0c;"><b><center><b>City</b></center></td>
<td><center><?= $un->city; ?></center></td>
</tr>

<tr>


<td><center><?= anchor('Welcome/delete_acc/'.$un->user_id,'Delete_acc',['class'=>'btn btn-primary']); ?></center></td>
<td><center><?= anchor('Welcome/edit_acc1/'.$un->user_id,'Edit_acc1',['class'=>'btn btn-primary']); ?></center></td>
</tr>
			
</table>
</div>
</div>

</div>
</body>
</html>