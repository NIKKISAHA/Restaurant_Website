<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE-edge" />
<meta name="viewport" content="width=device-width" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Home</title>
<link type="text/css" rel="stylesheet" href="<?=base_url('tool/css/s2.css'); ?>">
<link type="text/css" rel="stylesheet" href="<?= base_url('tool/css/bootstrap.min.css') ?>" >
<script src="<?= base_url('tool/js/bootstrap.js') ?>"> </script>
<script src="<?= base_url('tool/js/jquery-3.2.1.min.js')?>"></script>
<script src="<?= base_url('tool/js/myjs.js') ?>"></script>
<script>

</script>
</head>
<body style="background:silver;color:;">
<div class="container-fluid" style="background:#333333;color:#e68a00;">
<div class="col-sm-3">
<img src="<?php echo base_url();?>tool\img\logo.png" alt="" height="100" width="200"></div>
<div class="col-sm-9"><br>
<button id="btn" >--</button>
<div id='nav'>
	<?php 
$un=$this->session->userdata('us');
 ?>
<?php 
include('manu.php');
?>
</div>
</div>
</div>

<div class="container-fluid" id="banner">
<div id="form" class="col-sm-7"><br>
<?= form_open('Welcome/online_order'); ?>
<input type="hidden" value="ofline" name="type" >
<input type="hidden" value="<?php print_r($un->user_id); ?>" name="user_id" >
<input type="hidden" name="status" value="ordered">

<table class="table">
<tr>

<!-- <td>Product Name</td> -->
<input type="hidden" name="pname" value="<?php echo $d->name ?>">

</tr>
<tr>
<!-- <td>Product Price</td> -->
<input type="hidden" name="price" value="<?php echo $d->price ?>">
</tr>
<tr>
<td>Enter Coustemar Name</td>
<td><input type="hidden" name="cname" class="form-control" value="<?php print_r($un->name); ?>
">
	<?php print_r($un->name); ?>


</td>
</tr>
<tr>
<td>Enter E-Mail</td>
<td><input type="text" name="email" class="form-control" value="<?php print_r($un->email); ?>"></td>
</tr>
<tr>
<td>Enter Mobile No</td>
<td><input type="text" name="mno" class="form-control" value="<?php print_r($un->phone); ?>"></td>
</tr>
<tr>
<td>Enter Address</td>
<td><input type="text" name="address" class="form-control" value="<?php print_r($un->address); ?>"></td>
</tr>
<tr>
<td>Enter City</td>
<td><input type="text" name="city" class="form-control" value="<?php print_r($un->city); ?>"></td>
</tr>
<tr>
	<td>Payment mode</td>
	<td><input type="radio" id="cash" name="payment" value="cash" checked="cash">
    <label for="cash">cash on delivery</label></td><br>
</tr>
<tr>
<td><?= form_submit(['name'=>'sub','class'=>'btn btn-primary','value'=>'Book Now']) ?></td>
</tr>
</table>
</div>
</div>
<div class="container-fluid" style="background:blue;color:white;">

</div>
</body>
</html>