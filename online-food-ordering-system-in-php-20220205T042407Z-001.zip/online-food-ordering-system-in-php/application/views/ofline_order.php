<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE-edge" />
	<meta name="viewport" content="width=device-width" />
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Admin Home</title>
	<link type="text/css" rel="stylesheet" href="<?= base_url('tool/css/s2.css'); ?>">
	<link type="text/css" rel="stylesheet" href="<?= base_url('tool/css/bootstrap.min.css') ?>">
	

	 
	 
</head>

<body style="background:silver;color:;">
	<div class="container-fluid" style="background:#333333;color:#e68a00;">
		<div class="col-sm-3">
			<img src="<?php echo base_url(); ?>tool\img\logo.png" alt="" height="100" width="200">
		</div>
		<div class="col-sm-9"><br>
			<button id="btn">--</button>
			<div id='nav'>
				<?php
				echo $un = $this->session->userdata('un');

				?>
				<?php
				include('amanu.php');
				?>
			</div>
		</div>
	</div>
	<?= form_open('admin_welcome/status_up'); ?>


	<div class="container-fluid" id="banner">
		<div id="form" class="col-sm-9">
			<h3 style="color:blue">Order</h3>

			<!-- Orders Details Table 
			=========================================-->
			<table class="table">
				<!-- Table Headings -->
				<tr>
					<td style="color:red">ID</td>
					<td style="color:red">Name</td>
					<td style="color:red">Address</td>
					<td style="color:red">City</td>
					<td style="color:red">Product</td>
					<td style="color:red">Price</td>
					<td style="color:red">E-mail</td>
					<td style="color:red">Mobile No</td>
					<td style="color:red">User id</td>
					<td style="color:red">Status</td>
					<td style="color:red">Change Status</td>

				</tr>
				<!-- Table Headings End -->

				<?php foreach ($ofres as $of) { ?>

				<!-- Table Data -->
					<tr>
						<td><?= $of->id; ?></td>
						<td><?= $of->cname; ?></td>
						<td><?= $of->address; ?></td>
						<td><?= $of->city; ?></td>
						<td><?= $of->pname; ?></td>
						<td><?= $of->price; ?></td>
						<td><?= $of->email; ?></td>
						<td><?= $of->mno; ?></td>
						<td><?= $of->user_id; ?></td>
						<td><?= $of->status; ?></td>
						<td>

						<form class="text-center" method="post" action="<?php echo base_url('index.php/Admin_welcome/status_up'); ?>">
							<!-- hidden fields -->
							<input type="hidden" name="id" value="<?php echo $of->id ?>">
							<!-- hidden fields -->
							
							<select name="status" style="margin-bottom: 6px;" class="btn">
								<option  class="bg-success" value="Delivered" <?php echo ($of->status == 'Delivered')?'selected':'';?> >Delivered</option>
								<option class="bg-danger" value="Cancel" <?php echo ($of->status == 'Cancel')?'selected':'';?> >Cancel</option>
							</select>

							 
							<input type="submit" style="padding: 1px;" name="submit" value="Change Status !" class="btn-sm  btn-success">
						</form>


						</td>
					</tr>
				<!-- Table Data -->

				<?php } ?>
			</table>
		</div>
	</div>

	</div>






	<!-- Java Scripts
	============================================ -->
	<script src="<?= base_url('tool/js/bootstrap.js') ?>"> </script>
	<script src="<?= base_url('tool/js/jquery-3.2.1.min.js') ?>"></script>
	<script src="<?= base_url('tool/js/myjs.js') ?>"></script>
 
</body>

</html>