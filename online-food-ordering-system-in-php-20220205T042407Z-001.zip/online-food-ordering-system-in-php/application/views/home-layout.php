<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE-edge" />
<meta name="viewport" content="width=device-width" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Home</title>
<link type="text/css" rel="stylesheet" href="<?=base_url('tool/css/s2.css'); ?>">
<link type="text/css" rel="stylesheet" href="<?= base_url('tool/css/bootstrap.min.css') ?>" >
<script src="<?= base_url('tool/js/bootstrap.js') ?>"> </script>
<script src="<?= base_url('tool/js/jquery-3.2.1.min.js')?>"></script>
<script src="<?= base_url('tool/js/myjs.js') ?>"></script>
<script>

</script>
</head>
<body style="background:silver;color:;">
<div class="container-fluid" style="background:#333333;color:#e68a00;">
<div class="col-sm-3">
<img src="<?php echo base_url();?>tool\img\logo.png" alt="" height="100" width="200"></div>
<div class="col-sm-9"><br>
<button id="btn" >--</button>
<div id='nav'>
<?php 
 $un=$this->session->userdata('us');
?>
<?php 
include('manu.php');
?>
</div>
</div>
</div>


<div class="container-fluid" id="banner">
<div id="form" class="col-sm-7"><br>
<?= form_open('Welcome/search'); ?>
<table class="table">
<tr>
<td><?= form_input(['name'=>'search','placeholder'=>'Enter Product Name','title'=>'Enter Product Name','class'=>'form-control','id'=>'search']) ?></td>
<td><?= form_submit(['name'=>'sub','value'=>'Search','class'=>'btn btn-primary'])?></td>
</tr>
</table>
</div>
</div>
<div class="container-fluid" style="background:#333333;color:#e68a00;">
<h2 align="center"><h3>Toll Free: <span>1-800 123 45 67</span></h3>
              Copyright &copy; <a href="#">2021</a> All Rights Reserved<br>
            Design by Sandeep Agarwal,Soumi Koley,Sipra Bera</a></section></h2>
</div>
<h3 style="background:;color:#e68a00;">Follow Us </h3>
            <ul id="icons">
              <li><a href="#" class="normaltip"><img src="<?php echo base_url();?>tool\img\icon1.jpg" alt="" height="50" width="50"></a></li>
              <li><a href="#" class="normaltip"><img src="<?php echo base_url();?>tool\img\icon2.jpg" alt=""height="50" width="50"></a></li>
              <li><a href="#" class="normaltip"><img src="<?php echo base_url();?>tool\img\icon3.jpg" alt=""height="50" width="50"></a></li>
              <li><a href="#" class="normaltip"><img src="<?php echo base_url();?>tool\img\icon4.jpg" alt=""height="50" width="50"></a></li>
              
            </ul>

</div>
</body>
</html>