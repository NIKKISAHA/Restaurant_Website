<?php 
class User_model extends CI_Model
{
	public function search($s)
	{
		$q=$this->db->select(['id','name','price','type'])->from('product')->where('name',$s)->get();
		return $q->row();
	}
	public function search2()
	{
		$q=$this->db->select(['id','name','price','type','img'])->from('product')->get();
		return $q->result();
	}
	public function book_now($id)
	{
		$q=$this->db->select(['id','name','price'])->from('product')->where('id',$id)->get();
		return $q->row();
	}
	public function online_order_book($data)
	{
		return $this->db->insert('order_booking',$data);
	}
	public function search_res($email)
	{
		$q=$this->db->select(['id','pname','price','cname','email','mno','address','city','type'])->from('order_booking')->where('email',$email)->get();
		return $q->row();
	}

	public function saverecords($name,$email,$password,$phone,$address,$city)
	{
		$query="INSERT INTO `user`(`user_id`, `name`, `email`, `phone`, `password`, `address`, `city`) VALUES ('','$name','$email','$phone','$password','$address','$city')";
		if($this->db->query($query))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public function login($un,$ps)
	 {
		
		$q=$this->db->where(['email'=>$un,'password'=>$ps])->get('user');
		if($q->num_rows())
		{
			return $q->row();
		}
	}
	public function my_order($user_id){
		$q=$this->db->select(['id','pname','price','cname','email','mno','address','city','user_id','status'])->from('order_booking')->where('user_id',$user_id)->get();
		return $q->result();
	}
	function deleterecordsbyid($id)
{
    $sql="DELETE FROM `order_booking` WHERE id='$id'";
		if($this->db->query($sql))
		{
              return true;
		}
		else
		{
                return false;
		}
}
	public function del($id)
	{
		return $this->db->delete('user',['user_id'=>$id]);
	}


	public function edit1($id)
	{
		$q=$this->db->select(['user_id','name','email','phone','address','city'])->from('user')->where('user_id',$id)->get();
		return $q->row();
	}
	public function edit2($id,$name,$email,$phone,$city,$addess)
	{
		$query="UPDATE `user` SET `name`='$name',`email`='$email',`phone`='$phone',`address`='$addess',`city`='$city' WHERE user_id='$id'";
		if($this->db->query($query))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	function changepassword($u,$conp)
	{
		$sql="UPDATE `user` SET `password`='$conp' WHERE email= '$u'";
		if($this->db->query($sql))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public function edit3($id)
	{
		$q=$this->db->select(['user_id','name','email','phone','address','city'])->from('user')->where('user_id',$id)->get();
		return $q->row();
	}
	public function edit4($id,$name,$email,$phone,$city,$addess)
	{
		$query="UPDATE `user` SET `name`='$name',`email`='$email',`phone`='$phone',`address`='$addess',`city`='$city' WHERE user_id='$id'";
		if($this->db->query($query))
		{
			return true;
		}
		else
		{
			return false;
		}
	}





	/*===========================================  Defined by Sandeep ========================================  */


	/* Check Email Exist Or Not */
	function getemail($mail)
	{
		$Q = "SELECT * FROM `user` WHERE `email` = '$mail'";

		if($this->db->query($Q)->result())
		{
			return true ;
		}
		else
		{
			return false;
		}
	}


	/* Forget/Reset Password */
	function ResetPwd($mail,$pwd)
	{
		$Q= "UPDATE `user` SET `password`='$pwd' WHERE `email` = '$mail'";
		if($this->db->query($Q))
		{
			return true;
		}
		else
		{
			return false;
		}
	}


	

	/*===========================================  Defined by Sandeep End ========================================  */

}
