<?php
class Welcome extends CI_Controller
{
	function __construct()
	{
		parent ::__construct();
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->model('User_model');
	}



	// Home Page
	function index()
	{
		$this->load->view('home-layout');
	}
	function home()
	{
		$this->load->view('home-layout');
	}
	//  Home Page End



	// Product Showing Page
	function product()
	{
		    $this->load->model('user_model');
			$res=$this->user_model->search2();
			$this->load->view('product',['res'=>$res]);
	}
	// Product Showing Page End



	// Contact Page
	function contect()
	{
		$this->load->view('contect');
	}
	//  Contact Page End


	// Search Page
	function search()
	{
		$search=$this->input->post('search');
		$this->load->model('user_model');
		$res=$this->user_model->search($search);
		if($res)
		{
			$this->load->view('user-search-res',['res'=>$res]);
		}
		else
		{
			$this->load->model('user_model');
			$res=$this->user_model->search2();
			$this->load->view('other_product',['res'=>$res]);
		}
	}
	// Search Page End
 


	// 
	function book_now($id)
	{
		$this->load->model('user_model');
		$res=$this->user_model->book_now($id);
		if ($this->session->userdata('us')){
		$this->load->view('order',['d'=>$res]);
		}

		else{
			
			echo "***Plese login ";
			$this->load->view('user_login');
		}
	}
	
	
	
	
	public function online_order()
	{
		
					
		$data=$this->input->post();
		$email=$this->input->post('email');
		unset($data['sub']);
		unset($data['payment']);
		$this->load->model('user_model');
		$a=$this->user_model->online_order_book($data);
		if($a)
		{
			$this->load->model('user_model');
			$res=$this->user_model->search_res($email);
			$this->load->view('online_order_res',['res'=>$res]);
			
		}
	}



	// ====================================== Login/Registration Code ====================================
	public function user_registration()
	{
		$this->load->view('user_registration');
	}

	public function form_validation()
	{
		        $this->load->library('form_validation');
		        $this->form_validation->set_rules("name","User Name","required");
		        $this->form_validation->set_rules("email","Email ID","required|valid_email");
		        $this->form_validation->set_rules("mno","Mobile No","required|integer");
		        $this->form_validation->set_rules("pass","Password","required|alpha_numeric|max_length[15]|min_length[6]");
		        $this->form_validation->set_rules("address","Address","required");
		        $this->form_validation->set_rules("city","City","required|alpha");

                if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('user_registration');
                }
                else
                {
                	      /**echo "Not inserted";**/
                	$this->load->model('User_model');
                    if($this->input->post('submit'))
		            {
		                $nme= $this->input->post('name');
		                $email= $this->input->post('email');
		                $pass= md5($this->input->post('pass'));
		                $phn= $this->input->post('mno');
		                $add= $this->input->post('address');
		                $city= $this->input->post('city');
		              	if($this->User_model->saverecords($nme,$email,$pass,$phn,$add,$city))
		               	{
							  // this will send the mail automatic to the user who registered
							  $config = array(
								'protocol' => 'smtp',
								'smtp_host' => 'ssl://smtp.googlemail.com',
								'smtp_port' => 465,
								'smtp_user' => 'agarwal.sandeep.1520@gmail.com',
								'smtp_pass' => 'sandeep@8045',
								'charset' => 'iso-8859-1',
								'mailtype' => 'html',
								'wordwrap' => TRUE
							);
							$to = $email;
							$sub = "Thank you";
							$body = "Dear " . $nme . "," . "<br>" . "<br> Welcome to cafe Connections.<br>You have registered successfully.<br>Now you can login and Order Food.";
							
							$this->load->library('email', $config);
							$this->email->set_newline("\r\n");
							$this->email->from('cafe.connections@customer.com', '');

							$this->email->to($to);
							$this->email->subject($sub);
							$this->email->message($body);
							$this->email->send();
							$this->load->view('user_login');
		                }
		                else
		                {
			                  echo "Not inserted";
		                }
                }	}
	}
     

    public function login()
    {
    	$this->load->view('user_login');
    }
	public function login1()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules("email","User Name","required");
		$this->form_validation->set_rules("pass","Password","required");
		if($this->form_validation->run())
		{
			$un=$this->input->post('email');
			$ps=md5($this->input->post('pass'));
			$this->load->model('User_model','am');
			$u=$this->am->login($un,$ps);
			if($u)
			{
				    $this->load->library('session');
					$this->session->set_userdata('us',$u);
					$this->load->view('home-layout');
			}
			else
			{
				echo "Wrong User";
			}
		}
		else
		{
			$this->load->view('user_login');
		}
		
	}

	public function logout()
    {
        $this->session->unset_userdata('us');
        redirect('Welcome/login');
    }

    // Get Email For Forget Password
    function getEmailForForgetPassword()
    {
		$context= Array();
		
    	$_SESSION['email'] = $this->input->post('FpwdEmail');

		if($this->input->post('FpwdEmail'))
		{
			if($this->User_model->getemail($_SESSION['email']))
			{
				redirect(base_url('index.php/Welcome/forgetPassword'));
			}
			else
			{
				$context['msg'] = '<div class="alert alert-danger fw-bold text-center" role="alert">
				Please Enter Registered Email 
			  </div>';
			}


		}

		$this->load->view('password/ForgetPasswordgetEmail',$context);	
    }

    // forget Password Page
    function forgetPassword()
    {
		$context = Array();
		if($this->input->post('submit'))
		{
			$newpwd = $this->input->post('NewPassword');
			$conpwd = $this->input->post('ConfirmPassword');
			if($newpwd != $conpwd)
			{
				$context['msg'] = '
								<div class="alert alert-danger" role="alert">
									Password Did not Match !
								</div>';
			}
			else
			{
				$this->User_model->ResetPwd($_SESSION['email'],md5($newpwd));
				redirect(base_url('index.php/Welcome/login'));
			}
		}
    	$this->load->view('password/ForgotPassword',$context);

    }


	// Password Change
	function changepassword()
	{
		if(!empty($this->session->userdata('us')))
		{
			$context = Array();
			
			if($this->input->post('submit'))
			{
				$oldpwd = $this->input->post('oldPassword');
				$newpwd = $this->input->post('NewPassword');
				$confpwd = $this->input->post('ConfirmPassword');

				if($newpwd != $confpwd)
				{
					$context['msg'] = '
									<div class="alert alert-danger" role="alert">
										Password Did not Match !
									</div>';
				}
				elseif( md5($newpwd) == $this->session->userdata('us')->password)
				{
					$context['msg'] = '
					<div class="alert alert-danger" role="alert">
						You Entered Your Old Password !
					</div>';
				}
				elseif(empty($oldpwd))
				{
					$context['msg'] = '
					<div class="alert alert-danger" role="alert">
						Please Enter Old Password !
					</div>';
				}
				else
				{
					$If = $this->User_model->ResetPwd($this->session->userdata('us')->email,md5($newpwd));
					if($If)
					{
						
						$this->session->unset_userdata('us');
						redirect(base_url('index.php/Welcome/login1'));

					}
				}

			}
			$this->load->view('changepassword',$context);
		}
		else
		{
			redirect(base_url('index.php/Welcome/login'));
		}
	}
	// ====================================== Login/Registration Code End ====================================


    public function my_order(){
    	
    	$un=$this->session->userdata('us');

    	$this->load->model('User_model');
		$ofres=$this->User_model->my_order($un->user_id);
	
		$this->load->view('my_order',['ofres'=>$ofres]);
    }
    function deletedata()
		{
           $id=$this->input->get('del');
			$result['data']=$this->User_model->deleterecordsbyid($id);
		    // $this->load->view('delete',$result);
		    if($this->User_model->deleterecordsbyid($id))
		      {
                redirect("Welcome/my_order");

			}
			else
			{
				echo "Not updated";
			}
		}
    public function profile(){
    	$this->load->view('profile');
    }
    public function delete_acc($id)
	{
		$this->load->model('User_model');
		
		if($this->User_model->del($id))
		{
			 $this->session->unset_userdata('us');
			 $this->load->view('user_registration');
		}
		else
		{
			echo "Not Delete";
		}
	}

	public function edit_acc($id)
	{
		$this->load->model('User_model');
		$data=$this->User_model->edit1($id);
		//print_r($data);
		$this->load->view('edit_acc',['data'=>$data]);

	}
	public function edit2()
	{
	    $id=$this->input->post('user_id');
	    $name=$this->input->post('name');
	    $email=$this->input->post('email');
	    $phone=$this->input->post('phone');
	   // $password=md5($this->input->post('password'));
	    $city=$this->input->post('city');
	    $address=$this->input->post('address');
		$this->load->model('User_model');
		if($this->User_model->edit2($id,$name,$email,$phone,$city,$address))
		{
			$this->session->unset_userdata('us');
			$this->load->view('user_login');
		}
		else
		{
			echo "Not Update";
		}
	}
	public function edit_acc1($id)
	{
		$this->load->model('User_model');
		$data=$this->User_model->edit3($id);
		//print_r($data);
		$this->load->view('edit_acc1',['data'=>$data]);

	}
	public function edit4()
	{
	    $id=$this->input->post('user_id');
	    $name=$this->input->post('name');
	    $email=$this->input->post('email');
	    $phone=$this->input->post('phone');
	   // $password=md5($this->input->post('password'));
	    $city=$this->input->post('city');
	    $address=$this->input->post('address');
		$this->load->model('User_model');
		if($this->User_model->edit4($id,$name,$email,$phone,$city,$address))
		{
			$this->session->unset_userdata('us');
			$this->load->view('user_login');
		}
		else
		{
			echo "Not Update";
		}
	}
	

}
